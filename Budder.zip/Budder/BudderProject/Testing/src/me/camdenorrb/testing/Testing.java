package me.camdenorrb.testing;

/**
 * Created by camdenorrb on 10/7/16.
 */
public class Testing {

    private final static String[] strings = {
            "Meow",
            "HIss",
            "Scratch",
            "Meowth",
            "Pokemon",
            "Lexicographically",
            "More Meows",
            "It's me a Rubiks cube, aka your worst nightmare.",
            "Am I still lazy? Probably."
    };


    public static void main(String[] args) {

        try {
            int iterations = args.length == 0 ? 1 : Integer.valueOf(args[0]);
           // for (int i = (iterations * 16) / 16; )

        } catch (Exception ex) { System.out.println("You didn't do a good job.... Just saying.."); }
    }
}
