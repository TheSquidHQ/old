package me.camdenorrb.buddercore.events;

import org.bukkit.event.Cancellable;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

import java.util.UUID;

/**
 * Created by camdenorrb on 10/28/16.
 */
public class DataUpdateEvent<T> extends Event implements Cancellable {

    private boolean cancelled;

    private final UUID uuid;
    private final T oldValue, newValue;
    private final static HandlerList handlerList = new HandlerList();

    public DataUpdateEvent(UUID uuid, T oldValue, T newValue) {
        this.uuid = uuid;
        this.oldValue = oldValue;
        this.newValue = newValue;
    }

    @Override
    public boolean isCancelled() {
        return cancelled;
    }

    @Override
    public HandlerList getHandlers() {
        return handlerList;
    }

    @Override
    public void setCancelled(boolean cancelled) {
        this.cancelled = cancelled;
    }

    public UUID getUuid() {
        return uuid;
    }

    public T getOldValue() {
        return oldValue;
    }

    public T getNewValue() {
        return newValue;
    }

    public static HandlerList getHandlerList() {
        return handlerList;
    }

}
