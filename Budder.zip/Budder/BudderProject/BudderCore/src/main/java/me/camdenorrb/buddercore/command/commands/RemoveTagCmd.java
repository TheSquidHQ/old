package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/16/16.
 */
public class RemoveTagCmd extends Command {

    public RemoveTagCmd() {
        super(Rank.DEV, 1, "&c/removetag <PlayerName>", "removetag");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        return true;
    }
}
