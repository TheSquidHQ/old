package me.camdenorrb.buddercore.store;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.events.AsyncAccountLoadEvent;
import me.camdenorrb.buddercore.mysql.MySql;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.UUID;

/**
 * Created by camdenorrb on 10/3/16.
 */
public class AccountStore {

    private final MySql mySql;
    private final ScoreStore scoreStore;
    private final HashMap<UUID, Account> accountMap = new HashMap<>();

    public AccountStore(MySql mySql, ScoreStore scoreStore) {
        this.mySql = mySql;
        this.scoreStore = scoreStore;
    }

    public void disable() {
        accountMap.clear();
    }

    public HashMap<UUID, Account> accountMap() {
        return accountMap;
    }

    public Account account(UUID uuid) {
        return accountMap.get(uuid);
    }

    public AccountStore enable() {
        Bukkit.getOnlinePlayers().forEach(this::onJoin);
        return this;
    }

    public void onLeave(Player player) {
        scoreStore.onLeave(player);
        accountMap.remove(player.getUniqueId());
    }

    public void onJoin(Player player) {
        mySql.getAccount(player, account -> {
            accountMap.put(account.uuid, account);
            scoreStore.onJoin(player, account.rank());
            Bukkit.getPluginManager().callEvent(new AsyncAccountLoadEvent(player, account));
        });
    }
}
