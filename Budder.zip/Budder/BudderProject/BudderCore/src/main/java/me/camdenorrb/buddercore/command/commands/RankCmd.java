package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.mysql.MySql;
import me.camdenorrb.buddercore.mysql.SqlValueType;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import me.camdenorrb.buddercore.store.ScoreStore;
import me.camdenorrb.buddercore.utils.ChatUtils;
import me.camdenorrb.buddercore.utils.PlayerUtils;
import org.apache.commons.lang.StringUtils;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.List;
import java.util.UUID;

/**
 * Created by camdenorrb on 10/16/16.
 */
public class RankCmd extends Command {

    //TODO: Finish this.

    private final String RANK_HELP = ChatUtils.format("&aAvailable Ranks: &d") + StringUtils.join(Rank.values(), ", ");

    private final MySql mySql;
    private final ScoreStore scoreStore;
    private final AccountStore accountStore;

    public RankCmd(MySql mySql, ScoreStore scoreStore, AccountStore accountStore) {
        super(Rank.ADMIN, 2, "&c/rank [Username] [Rank]", "rank");
        this.mySql = mySql;
        this.scoreStore = scoreStore;
        this.accountStore = accountStore;
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        Rank newRank = Rank.byName(args.get(1)).orElse(null);
        if (newRank == null) { sender.sendMessage(RANK_HELP); return true; }

        OfflinePlayer offlinePlayer = PlayerUtils.getOfflinePlayer(args.get(0));
        if (offlinePlayer == null) { sender.sendMessage(ChatColor.RED + "That player is not logged in our databases."); return true; }

        UUID uuid = offlinePlayer.getUniqueId();
        mySql.set(uuid, SqlValueType.RANK, newRank.name());
        sender.sendMessage(ChatColor.GREEN + "Updated " + offlinePlayer.getName() + "'s rank to " + ChatColor.DARK_PURPLE + newRank.name());

        if (!offlinePlayer.isOnline()) return true;

        Player player = offlinePlayer.getPlayer();
        scoreStore.onJoin(player.getPlayer(), newRank);
        accountStore.account(player.getUniqueId()).setRank(newRank);
        player.sendMessage(ChatColor.GREEN + "You are now " + ChatColor.DARK_PURPLE + newRank.name());

        return true;
    }
}
