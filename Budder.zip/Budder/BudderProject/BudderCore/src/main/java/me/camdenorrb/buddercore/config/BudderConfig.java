package me.camdenorrb.buddercore.config;

/**
 * Created by camdenorrb on 9/13/16.
 */
public class BudderConfig {

    public Integer port = 3306;
    public String ip = "127.0.0.1", database = "budderDatabase", username = "DaKatUsername", password = "qwerty", unknownCmdMsg = "&cUnknown Command!";

    public BudderConfig() {}

    public BudderConfig(Integer port, String ip, String database, String username, String password, String unknownCmdMsg) {
        this.ip = ip;
        this.port = port;
        this.username = username;
        this.password = password;
        this.database = database;
        this.unknownCmdMsg = unknownCmdMsg;
    }
}