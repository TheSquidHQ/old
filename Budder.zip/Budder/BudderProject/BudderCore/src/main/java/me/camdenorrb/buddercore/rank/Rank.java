package me.camdenorrb.buddercore.rank;

import me.camdenorrb.buddercore.BudderCore;
import me.camdenorrb.buddercore.utils.ChatUtils;

import java.util.Optional;
import java.util.stream.Stream;

/**
 * Created by camdenorrb on 9/13/16.
 */
public enum Rank {

    //staff ranks
    ADMIN("&4&lADMIN&r", 10),
    DEV("&e&lDEV&r", 9),
    MOD("&b&lMOD&r&b", 8),
    TRAINEE("&3&lTRAINEE&r", 7),
    BUILDER("&2&lBUILDER&r", 6),

    //social media rank
    YOUTUBER("&c&lY&f&lT&r&7", 5),

    //donation ranks
    BUDDER("&6&lBUDDER&r&7", 4),
    EMERALD("&a&lEMERALD&r&7", 3),
    SILVER("&7&lSILVER&r&7", 2),

    //normal rank
    RECRUIT("&8", 1);

    private final int level;
    private final String prefix, boardName;

    Rank(String prefix, int level) {
        this.level = level;
        this.boardName = calcBoardName();
        this.prefix = ChatUtils.format(prefix);
        BudderCore.instance().scoreStore().registerTeam(this);
    }

    public int level() {
        return level;
    }

    public String prefix() {
        return prefix;
    }

    public String boardName() {
        return boardName;
    }

    public static Optional<Rank> byName(String name) {
        return Stream.of(values()).filter(rank -> rank.name().equals(name)).findFirst();
    }

    private String calcBoardName() {
        int firstPlace = level % 10, tenthPlace = (level - firstPlace) / 10;
        return (char) (65 + tenthPlace) + "" + (9 - firstPlace);
    }
}
