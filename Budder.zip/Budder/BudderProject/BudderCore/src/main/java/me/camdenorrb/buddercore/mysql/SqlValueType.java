package me.camdenorrb.buddercore.mysql;

/**
 * Created by camdenorrb on 10/16/16.
 */
public enum SqlValueType {

    TAG("tag"), RANK("rank"), TOKENS("tokens"), COINS("coins");

    private final String valueName;

    SqlValueType(String valueName) {
        this.valueName = valueName;
    }

    @Override
    public String toString() {
        return valueName;
    }

}
