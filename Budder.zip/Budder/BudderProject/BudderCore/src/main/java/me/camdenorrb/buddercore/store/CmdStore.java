package me.camdenorrb.buddercore.store;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

/**
 * Created by camdenorrb on 10/2/16.
 */
public class CmdStore {

    private final Set<Command> commandSet = new TreeSet<>(Command::compareTo);

    public void disable() {
        commandSet.clear();
    }

    public void register(Command... commands) {
        Collections.addAll(commandSet, commands);
    }

    public boolean execute(CommandSender sender, Account account, Rank rank, String name, List<String> args) {
        Command command = commandSet.stream().filter(cmd -> cmd.nameList().contains(name)).findFirst().orElse(null);
        if (command == null) return false;
        if (command.rank().level() > rank.level()) { sender.sendMessage(ChatColor.RED + "Sorry! You need " + command.rank().prefix() + ChatColor.RED + " to perform this command!"); return true; }
        if (command.argsLength() > args.size() || !command.execute(sender, account, rank, name, args)) if (command.hasUsage()) sender.sendMessage(command.usage());
        return true;
    }
}
