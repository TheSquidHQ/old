package me.camdenorrb.buddercore.account;

import me.camdenorrb.buddercore.BudderCore;
import me.camdenorrb.buddercore.events.DataUpdateEvent;
import me.camdenorrb.buddercore.mysql.SqlValueType;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.util.UUID;

/**
 * Created by camdenorrb on 10/23/16.
 */
public class Account {

    private final transient Player player;

    private Rank rank;
    private String tag;
    private long coins, tokens;
    private boolean canBuild, vanished;

    public final UUID uuid;
    public final String name;

    public Account(Player player, long coins, Rank rank, String tag) {
        this.tag = tag;
        this.rank = rank;
        this.coins = coins;
        this.player = player;
        name = player.getName();
        uuid = player.getUniqueId();
    }

    public Rank rank() {
        return rank;
    }

    public String tag() {
        return tag;
    }

    public long coins() {
        return coins;
    }

    public String name() {
        return name;
    }

    public long tokens() {
        return tokens;
    }

    public Player player() {
        return player;
    }

    public int level() {
        return rank.level();
    }

    public boolean canBuild() {
        return canBuild;
    }

    public boolean isVanished() {
        return vanished;
    }

    public void setCanBuild(boolean canBuild) {
        this.canBuild = canBuild;
    }

    public void setVanished(boolean vanished) {
        this.vanished = vanished;
    }

    public void setTag(String tag) {
        this.tag = tag;
        BudderCore.instance().mySQL().set(uuid, SqlValueType.TAG, tag);
    }

    public void setRank(Rank rank) {
        DataUpdateEvent<Rank> dataUpdateEvent = new DataUpdateEvent<>(uuid, this.rank, rank);
        Bukkit.getPluginManager().callEvent(dataUpdateEvent);
        if (dataUpdateEvent.isCancelled()) return;

        this.rank = rank;
        BudderCore.instance().mySQL().set(uuid, SqlValueType.RANK, rank.name());
    }

    public void setCoins(long coins) {
        this.coins = coins;
        BudderCore.instance().mySQL().set(uuid, SqlValueType.COINS, String.valueOf(coins));
    }

    public void setTokens(long tokens) {
        this.tokens = tokens;
        BudderCore.instance().mySQL().set(uuid, SqlValueType.TOKENS, String.valueOf(tokens));
    }
}
