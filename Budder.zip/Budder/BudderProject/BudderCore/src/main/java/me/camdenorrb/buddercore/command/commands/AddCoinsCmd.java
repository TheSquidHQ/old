package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/6/16.
 */
public class AddCoinsCmd extends Command {

    private final AccountStore accountStore;

    public AddCoinsCmd(AccountStore accountStore) {
        super(Rank.ADMIN, 2, "/addcoins <player> <amount>", "addcoins");
        this.accountStore = accountStore;
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        try {
            int amount = Integer.valueOf(args.get(1));
            Account account1 = accountStore.account(Bukkit.getPlayerExact(args.get(0)).getUniqueId());
            if (account1 == null) return false;
            account1.setCoins(account1.coins() + amount);
            sender.sendMessage(ChatColor.GREEN + "Added " + amount + " coins to " + account1.name() + "!");


        } catch (Exception ex) { return false; }

        return true;
    }
}
