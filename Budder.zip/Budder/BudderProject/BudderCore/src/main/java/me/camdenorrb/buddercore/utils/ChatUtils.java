package me.camdenorrb.buddercore.utils;

import org.bukkit.ChatColor;

/**
 * Created by camdenorrb on 9/13/16.
 */
public class ChatUtils {

    public static String format(String text) {
        return ChatColor.translateAlternateColorCodes('&', text);
    }

}
