package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/11/16.
 */
public class PunishCmd extends Command {

    //TODO: Finish this.

    public PunishCmd() {
        super(Rank.TRAINEE, 1, "&c/punish <Name> (Reason)", "punish");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {


        return true;
    }
}
