package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/7/16.
 */
public class HelpCmd extends Command {

    public HelpCmd() {
        super(Rank.RECRUIT, "help");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        return true;
    }
}
