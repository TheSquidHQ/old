package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/12/16.
 */
public class ReloadCmd extends Command {

    public ReloadCmd() {
        super(Rank.ADMIN, "reload", "rl");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        Bukkit.broadcastMessage(ChatColor.RED + "" + ChatColor.BOLD + "Server reload incoming, saving data...");
        Bukkit.reload();
        Bukkit.broadcastMessage(ChatColor.GREEN + "" + ChatColor.BOLD + "Server reload is Complete.");
        return true;
    }
}
