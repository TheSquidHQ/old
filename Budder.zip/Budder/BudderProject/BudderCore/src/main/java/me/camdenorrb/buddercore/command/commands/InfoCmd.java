package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/10/16.
 */
public class InfoCmd extends Command {

    private final AccountStore accountStore;

    public InfoCmd(AccountStore accountStore) {
        super(Rank.DEV, 1, "&c/info <Online Player>", "info");
        this.accountStore = accountStore;
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        Account foundAccount = accountStore.accountMap().values().stream().filter(account1 -> account1.name().equalsIgnoreCase(args.get(0))).findFirst().orElse(null);
        if (foundAccount == null) return false;

        sender.sendMessage(new String[] {
                ChatColor.RED + foundAccount.name() + ChatColor.WHITE + "'s Player Data:",
                ChatColor.GRAY + "Rank: " + ChatColor.WHITE + foundAccount.rank().prefix(),
                ChatColor.GRAY + "Tag: " + ChatColor.WHITE + foundAccount.tag(),
                ChatColor.GRAY + "Coins: " + ChatColor.WHITE + foundAccount.coins(),
                ChatColor.GRAY + "Tokens: " + ChatColor.WHITE + foundAccount.tokens()
        });

        return true;
    }
}
