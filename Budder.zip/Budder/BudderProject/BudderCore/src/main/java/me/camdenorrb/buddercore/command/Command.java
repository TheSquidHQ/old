package me.camdenorrb.buddercore.command;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.utils.ChatUtils;
import org.bukkit.command.CommandSender;

import java.util.Collections;
import java.util.HashSet;
import java.util.List;

/**
 * Created by camdenorrb on 9/14/16.
 */
public abstract class Command implements Comparable<Command> {

    private String usage, name;
    private int argsLength = 0;

    private final Rank rank;
    private final HashSet<String> nameList = new HashSet<>();

    public Command(Rank rank, String name, String... aliases) {
        this(rank, 0, "", name, aliases);
    }

    public Command(Rank rank, Integer argsLength, String usage, String name, String... aliases) {
        this.name = name;
        this.rank = rank;
        this.argsLength = argsLength;
        this.usage = usage.isEmpty() ? "" : ChatUtils.format(usage);

        nameList.add(name);
        Collections.addAll(nameList, aliases);
    }

    @Override
    public int compareTo(Command command) {
        return name.compareTo(command.name);
    }

    public Rank rank() {
        return rank;
    }

    public String name() {
        return name;
    }

    public String usage() {
        return usage;
    }

    public int argsLength() {
        return argsLength;
    }

    public HashSet<String> nameList() {
        return nameList;
    }

    public boolean hasUsage() {
        return !usage.isEmpty();
    }

    public void setArgsLength(int argsLength) {
        this.argsLength = argsLength;
    }

    public void setUsage(String usage) {
        this.usage = ChatUtils.format(usage);
    }

    public abstract boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args);

}
