package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/7/16.
 */
public class CoinsCmd extends Command {

    public CoinsCmd() {
        super(Rank.RECRUIT, "coins");
        setUsage("&c/coins");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        if (account == null) return false;
        sender.sendMessage(ChatColor.GOLD + "Current Coins: " + ChatColor.GRAY + account.coins());
        return true;
    }
}
