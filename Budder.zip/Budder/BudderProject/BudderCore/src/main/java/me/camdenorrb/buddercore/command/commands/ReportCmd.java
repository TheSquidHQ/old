package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import net.md_5.bungee.api.ChatColor;
import net.md_5.bungee.api.chat.ClickEvent;
import net.md_5.bungee.api.chat.ComponentBuilder;
import net.md_5.bungee.api.chat.HoverEvent;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Created by camdenorrb on 10/15/16.
 */
public class ReportCmd extends Command {

    public ReportCmd() {
        super(Rank.RECRUIT, "report");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        if (sender instanceof ConsoleCommandSender) return false;

        TextComponent c = new TextComponent("here!");
        c.setUnderlined(true);
        c.setColor(ChatColor.AQUA);
        c.setClickEvent(new ClickEvent(ClickEvent.Action.OPEN_URL, "http://squid-network.com/forumdisplay.php?fid=27"));
        c.setHoverEvent(new HoverEvent(HoverEvent.Action.SHOW_TEXT, new ComponentBuilder("Click Me!").create()));
        TextComponent msg = new TextComponent(ChatColor.YELLOW + "Found a hacker or troublemaker? Report them ");
        msg.addExtra(c);
        ((Player) sender).spigot().sendMessage(msg);
        return true;
    }
}
