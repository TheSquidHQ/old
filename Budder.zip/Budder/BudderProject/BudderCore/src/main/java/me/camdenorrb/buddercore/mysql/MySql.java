package me.camdenorrb.buddercore.mysql;

import com.zaxxer.hikari.HikariDataSource;
import me.camdenorrb.buddercore.BudderCore;
import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.utils.Call;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.UUID;

/**
 * Created by camdenorrb on 9/13/16.
 */
public class MySql {

    private final HikariDataSource hikariDataSource = new HikariDataSource();

    public MySql(String ip, int port, String database, String username, String password) {
        hikariDataSource.setJdbcUrl("jdbc:mysql://" + ip + ':' + port + '/' + database);
        hikariDataSource.setUsername(username);
        hikariDataSource.setPassword(password);

        BudderCore.runAsync(() -> {
            try (Connection resource = hikariDataSource.getConnection(); PreparedStatement statement = resource.prepareStatement("CREATE TABLE IF NOT EXISTS Users(uuid VARCHAR(36) not null primary key, rank VARCHAR(16), tag VARCHAR(16), coins BIGINT(50), tokens BIGINT(50));")) { statement.execute(); }
            catch (Exception ex) { ex.printStackTrace(); Bukkit.shutdown(); }
        });
    }

    public void disable() {
        hikariDataSource.close();
    }

    public HikariDataSource hikariDataSource() {
        return hikariDataSource;
    }

    public Connection resource() {
        try {return hikariDataSource.getConnection();}
        catch (SQLException e) {e.printStackTrace();}
        return null;
    }

    public void getAccount(Player player, Call<Account> call) {
        getAll(player.getUniqueId(), resultSet -> {
            try {call.call(resultSet.next() ? new Account(player, resultSet.getLong("coins"), Rank.byName(resultSet.getString("rank")).orElse(Rank.RECRUIT), resultSet.getString("tag")) : new Account(player, 0L, Rank.RECRUIT, ""));}
            catch (Exception ex) { ex.printStackTrace(); }
        });
    }

    public void getAll(UUID key, Call<ResultSet> call) {
        BudderCore.runAsync(() -> {
            try (Connection connection = resource(); PreparedStatement preparedStatement = connection.prepareStatement("SELECT * FROM Users WHERE uuid=?")) {
                preparedStatement.setString(1, key.toString());
                call.call(preparedStatement.executeQuery());

            } catch (SQLException e) {e.printStackTrace();}
        });
    }

    public void getCoins(UUID uuid, Call<Long> call) {
        getAll(uuid, resultSet -> {
            try {call.call(resultSet.next() ? resultSet.getLong("coins") : 0L);}
            catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public void getTokens(UUID uuid, Call<Long> call) {
        getAll(uuid, resultSet -> {
            try {call.call(resultSet.next() ? resultSet.getLong("tokens") : 0L);}
            catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public void getTag(UUID uuid, Call<String> call) {
        getAll(uuid, resultSet -> {
            try { call.call(resultSet.next() ? resultSet.getString("tag") : "");}
            catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public void getRank(UUID uuid, Call<Rank> call) {
        getAll(uuid, resultSet -> {
            try {
                if (resultSet.next()) call.call(Rank.byName(resultSet.getString("rank")).orElse(Rank.RECRUIT));
                else call.call(Rank.RECRUIT);

            } catch (SQLException e) { e.printStackTrace(); }
        });
    }

    public void set(UUID key, SqlValueType sqlValueType, String value) {
        BudderCore.runAsync(() -> {
            try (Connection connection = resource(); PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Users(uuid, " + sqlValueType + ") VALUES(?, ?) ON DUPLICATE KEY UPDATE " + sqlValueType + "=VALUES(" + sqlValueType + ')')) {
                preparedStatement.setString(1, key.toString());
                preparedStatement.setString(2, value);
                preparedStatement.executeUpdate();

            } catch (Exception ex) { ex.printStackTrace(); }
        });
    }
}




    /*private PreparedStatement prepare(Connection connection, String query, Call<PreparedStatement> call) throws SQLException {
        PreparedStatement statement = connection.prepareStatement(query);
        call.call(statement);
        return statement;
    }*/
