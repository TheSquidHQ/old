package me.camdenorrb.buddercore.utils;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.entity.Player;

/**
 * Created by camdenorrb on 10/10/16.
 */
public class PlayerUtils {

    public static OfflinePlayer getOfflinePlayer(String name) {
        for (Player player : Bukkit.getOnlinePlayers()) if (player.getName().equalsIgnoreCase(name)) return player;
        for (OfflinePlayer offlinePlayer : Bukkit.getOfflinePlayers()) if (offlinePlayer.getName().equalsIgnoreCase(name)) return offlinePlayer;
        return null;
    }
}
