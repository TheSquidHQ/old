package me.camdenorrb.buddercore.position;

import org.bukkit.Location;

/**
 * Created by camdenorrb on 10/12/16.
 */
public class Position {

    public final double x, y, z;
    public final String worldName;
    public final float yaw, pitch;

    public Position(double x, double y, double z, String worldName, float yaw, float pitch) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.yaw = yaw;
        this.pitch = pitch;
        this.worldName = worldName;
    }

    public Position(Location loc) {
        this.x = loc.getX();
        this.y = loc.getY();
        this.z = loc.getZ();
        this.yaw = loc.getYaw();
        this.pitch = loc.getPitch();
        this.worldName = loc.getWorld().getName();
    }
}
