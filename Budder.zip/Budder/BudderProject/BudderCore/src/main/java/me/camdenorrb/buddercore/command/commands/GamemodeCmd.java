package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.List;

import static org.bukkit.ChatColor.*;

/**
 * Created by camdenorrb on 10/10/16.
 */
public class GamemodeCmd extends Command {

    public GamemodeCmd() {
        super(Rank.DEV, "gamemode", "gm", "gmc", "gma", "gms", "gmsp", "gm0", "gm1", "gm2", "gm3");
        setUsage("&c/Gamemode [Mode] (Player)");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        GameMode gamemode = commandName.startsWith("gm") && commandName.length() > 2 ? getGamemode(commandName.substring(2).toLowerCase()) : args.size() >= 1 ? getGamemode(args.remove(0).toLowerCase()) : null;
        if (gamemode == null) return false;

        if (sender instanceof ConsoleCommandSender && args.size() == 0) return false;
        Player player = args.size() == 0 ? (Player) sender : Bukkit.getPlayer(args.remove(0));
        if (player == null) return false;

        player.setGameMode(gamemode);
        player.sendMessage(GREEN + "Your gamemode is now " + GRAY + gamemode);
        if (!player.getName().equals(sender.getName())) sender.sendMessage(GREEN + "You updated " + GRAY + player.getName() + GREEN + " gamemode to " + GRAY + gamemode);
        return true;
    }

    private GameMode getGamemode(String gamemode) {
        if (gamemode.startsWith("c") || gamemode.equals("1")) return GameMode.CREATIVE;
        if (gamemode.startsWith("a") || gamemode.equals("2")) return GameMode.ADVENTURE;
        if (gamemode.startsWith("sp") || gamemode.equals("3")) return GameMode.SPECTATOR;
        if (gamemode.startsWith("s") || gamemode.equals("0")) return GameMode.SURVIVAL;
        return null;
    }
}

