package me.camdenorrb.buddercore.listeners;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import me.camdenorrb.buddercore.store.CmdStore;
import me.camdenorrb.buddercore.utils.ChatUtils;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;

import java.util.ArrayList;
import java.util.Collections;

/**
 * Created by camdenorrb on 9/13/16.
 */
public class CmdListener implements Listener {

    private final String unknownMsg;
    private final CmdStore cmdStore;
    private final AccountStore accountStore;

    public CmdListener(AccountStore accountStore, CmdStore cmdStore, String unknownMsg) {
        this.cmdStore = cmdStore;
        this.accountStore = accountStore;
        this.unknownMsg = ChatUtils.format(unknownMsg);
    }

    @EventHandler (ignoreCancelled = true)
    public void onConsoleCmd(ServerCommandEvent event) {
        ArrayList<String> args = new ArrayList<>();
        Collections.addAll(args, event.getCommand().split(" "));
        if (cmdStore.execute(event.getSender(), null, Rank.ADMIN, args.remove(0).toLowerCase(), args)) event.setCancelled(true);
    }

    @EventHandler (ignoreCancelled = true)
    public void onPlayerCmd(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();
        ArrayList<String> args = new ArrayList<>();
        Collections.addAll(args, event.getMessage().split(" "));
        Account account = accountStore.account(player.getUniqueId());
        if (!cmdStore.execute(player, account, account.rank(), args.remove(0).substring(1).toLowerCase(), args)) player.sendMessage(unknownMsg);
        event.setCancelled(true);
    }
}

