package me.camdenorrb.buddercore.utils;

/**
 * Created by camdenorrb on 9/13/16.
 */
public interface Call<D> {

    void call(D data);

    default void onFail() {}

}
