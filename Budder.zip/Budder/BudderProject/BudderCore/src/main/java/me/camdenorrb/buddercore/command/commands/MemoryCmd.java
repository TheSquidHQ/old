package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import java.util.List;

import static org.bukkit.ChatColor.*;

/**
 * Created by camdenorrb on 10/11/16.
 */
public class MemoryCmd extends Command {

    private final Runtime runtime = Runtime.getRuntime();

    public MemoryCmd() {
        super(Rank.DEV, "memory");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        sender.sendMessage(
                GREEN + "Players Online: " + GRAY + Bukkit.getOnlinePlayers().size() + '\n' +
                GREEN + "Max Memory: " + GRAY + Math.round(runtime.maxMemory() / 1048576) + "MB" + '\n' +
                GREEN + "Used Memory: " + GRAY + Math.round((runtime.maxMemory() - runtime.freeMemory()) / 1048576) + "MB" + '\n' +
                GREEN + "Free Memory: " + GRAY + Math.round(runtime.freeMemory() / 1048576) + "MB"
        );
        return true;
    }
}
