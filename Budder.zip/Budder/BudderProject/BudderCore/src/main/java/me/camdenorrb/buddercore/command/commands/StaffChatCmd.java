package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/12/16.
 */
public class StaffChatCmd extends Command {

    private final AccountStore accountStore;

    public StaffChatCmd(AccountStore accountStore) {
        super(Rank.BUILDER, 1, "&c/sc <Message>",  "sc");
        this.accountStore = accountStore;
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        StringBuilder stringBuilder = new StringBuilder(ChatColor.RED + "Staff Chat: " + ChatColor.GRAY + sender.getName() + ChatColor.RESET + ": ");
        for (String string : args) stringBuilder.append(string).append(' ');
        String message = stringBuilder.toString();

        Bukkit.getOnlinePlayers().stream().filter(player -> !player.getName().equals(sender.getName()) && accountStore.account(player.getUniqueId()).level() >= 6).forEach(player -> player.sendMessage(message));

        return true;
    }
}
