package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/6/16.
 */
public class BuildCmd extends Command {

    public BuildCmd() {
        super(Rank.BUILDER, "build");
        setUsage("&c/build");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        if (account == null) return false;
        if (!Bukkit.hasWhitelist() && account.rank() != Rank.ADMIN) { sender.sendMessage(ChatColor.RED + "Maintenance Mode is not enabled!"); return true; }

        account.setCanBuild(!account.canBuild());
        sender.sendMessage(account.canBuild() ? ChatColor.GREEN + "Enabled Build Mode" : ChatColor.RED + "Disabled Build Mode");
        return true;
    }
}
