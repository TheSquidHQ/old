package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.WorldCreator;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/11/16.
 */
public class LoadWorldCmd extends Command {

    public LoadWorldCmd() {
        super(Rank.ADMIN, 1, "&c/loadworld <name>", "loadworld");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        String name = args.get(0);
        if (Bukkit.getWorld(name) == null) {
            Bukkit.createWorld(new WorldCreator(name));
            sender.sendMessage(ChatColor.YELLOW + "Creating/loading new world, please wait for it to finish...");

        } else sender.sendMessage(ChatColor.RED + "World is already loaded, use /world " + name + " to teleport!");

        return true;
    }
}
