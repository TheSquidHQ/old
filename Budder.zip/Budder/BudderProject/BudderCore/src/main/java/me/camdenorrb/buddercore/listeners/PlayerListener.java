package me.camdenorrb.buddercore.listeners;

import me.camdenorrb.buddercore.BudderCore;
import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.events.AsyncAccountLoadEvent;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.player.*;

/**
 * Created by camdenorrb on 10/6/16.
 */
public class PlayerListener implements Listener {

    private final AccountStore accountStore;

    public PlayerListener(AccountStore accountStore) {
        this.accountStore = accountStore;
    }

    @EventHandler (ignoreCancelled = true)
    public void onJoin(PlayerJoinEvent event) {
        accountStore.onJoin(event.getPlayer());
    }

    @EventHandler (ignoreCancelled = true)
    public void onLeave(PlayerQuitEvent event) {
        accountStore.onLeave(event.getPlayer());
    }

    @EventHandler (ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent event) {
        if (!accountStore.account(event.getPlayer().getUniqueId()).canBuild()) event.setCancelled(true);
    }

    @EventHandler (ignoreCancelled = true)
    public void onBreak(BlockBreakEvent event) {
        if (!accountStore.account(event.getPlayer().getUniqueId()).canBuild()) event.setCancelled(true);
    }

    @EventHandler (ignoreCancelled = true)
    public void onBucket(PlayerBucketEmptyEvent event) {
        if (!accountStore.account(event.getPlayer().getUniqueId()).canBuild()) event.setCancelled(true);
    }

    @EventHandler (ignoreCancelled = true)
    public void onStomp(PlayerInteractEvent event) {
        if (event.getAction() == Action.PHYSICAL && event.getClickedBlock().getType() == Material.SOIL) event.setCancelled(true);
    }

    @EventHandler (ignoreCancelled = true, priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player player = event.getPlayer();
        Account account = accountStore.account(player.getUniqueId());
        if (account != null) Bukkit.broadcastMessage(account.rank().prefix() + (account.rank() == Rank.RECRUIT ? player.getName() + ChatColor.GRAY : ' ' + player.getName() + ChatColor.RESET) + ": " + event.getMessage());
        event.setCancelled(true);
    }

    @EventHandler (ignoreCancelled = true)
    public void onRankLoad(AsyncAccountLoadEvent event) {

        Player player = event.player();
        if (Bukkit.getServer().hasWhitelist() && event.account().level() < 6) { Bukkit.getScheduler().runTask(BudderCore.instance(), () -> player.kickPlayer(ChatColor.RED + "Server is under maintenance, please try again later.")); return; }

        player.getAttribute(Attribute.GENERIC_ATTACK_SPEED).setBaseValue(32);
        accountStore.accountMap().values().stream().filter(account -> !account.name().equals(player.getName()) && account.isVanished()).forEach(account -> player.hidePlayer(account.player()));
    }
}
