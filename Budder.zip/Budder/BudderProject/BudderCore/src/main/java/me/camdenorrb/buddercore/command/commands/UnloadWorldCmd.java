package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/16/16.
 */
public class UnloadWorldCmd extends Command {

    public UnloadWorldCmd() {
        super(Rank.DEV, "&c/unloadworld <WorldName>", "unloadworld");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        World world = Bukkit.getWorld(args.get(0));
        if (world == null) return false;

        Location toLoc = Bukkit.getWorlds().get(0).getSpawnLocation();
        Bukkit.getOnlinePlayers().stream().filter(player -> player.getWorld().getName().equals(world.getName())).forEach(player -> player.teleport(toLoc));
        Bukkit.unloadWorld(world, true);

        sender.sendMessage(ChatColor.YELLOW + "Unloaded world " + args.get(0) + '!');

        return true;
    }
}
