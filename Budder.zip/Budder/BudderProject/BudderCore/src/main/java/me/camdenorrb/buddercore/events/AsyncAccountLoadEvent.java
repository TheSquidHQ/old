package me.camdenorrb.buddercore.events;

import me.camdenorrb.buddercore.account.Account;
import org.bukkit.entity.Player;
import org.bukkit.event.Event;
import org.bukkit.event.HandlerList;

/**
 * Created by camdenorrb on 10/6/16.
 */
public class AsyncAccountLoadEvent extends Event {

    private final Player player;
    private final Account account;

    private static final HandlerList handlerList = new HandlerList();

    public AsyncAccountLoadEvent(Player player, Account account) {
        super(true);
        this.player = player;
        this.account = account;
    }

    @Override
    public HandlerList getHandlers() {
        return handlerList;
    }

    public Player player() {
        return player;
    }

    public Account account() {
        return account;
    }

    public static HandlerList getHandlerList() {
        return handlerList;
    }
}
