package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.Listener;

import java.util.List;

/**
 * Created by camdenorrb on 10/15/16.
 */
public class VanishCmd extends Command implements Listener {

    public VanishCmd() {
        super(Rank.DEV, "vanish");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        if (account == null) return false;

        account.setVanished(!account.isVanished());

        if (account.isVanished()) for (Player player : Bukkit.getOnlinePlayers()) player.hidePlayer((Player) sender);
        else for (Player player : Bukkit.getOnlinePlayers()) player.showPlayer((Player) sender);
        sender.sendMessage(account.isVanished() ? ChatColor.GREEN + "Enabled Vanish" : ChatColor.RED + "Disabled Vanish");

        return true;
    }
}
