package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/11/16.
 */
public class MaintenanceCmd extends Command {

    private final AccountStore accountStore;

    public MaintenanceCmd(AccountStore accountStore) {
        super(Rank.ADMIN, 2, "&c/maintenance <On/Off>", "maintenance");
        this.accountStore = accountStore;
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        String arg = args.get(0).toLowerCase();
        Boolean state = arg.equals("on") || arg.equals("off") ? arg.equals("on") : null;
        if (state == null) return false;

        Bukkit.setWhitelist(state);
        sender.sendMessage(state ? ChatColor.GREEN + "Enabled Maintenance Mode" : ChatColor.RED + "Disabled Maintenance Mode");
        if (state) Bukkit.getOnlinePlayers().stream().filter(player -> accountStore.account(player.getUniqueId()).rank().level() < 6).forEach(player -> player.kickPlayer("Server went down for maintenance, please try again later!"));

        return true;
    }
}
