package me.camdenorrb.buddercore.store;

import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.stream.Stream;

/**
 * Created by camdenorrb on 10/3/16.
 */
public class ScoreStore {

    private Scoreboard scoreboard;

    public Scoreboard scoreboard() {
        return scoreboard;
    }

    public void disable() {
        scoreboard.getTeams().forEach(Team::unregister);
    }

    public void enable() {
        scoreboard = Bukkit.getScoreboardManager().getNewScoreboard();
        Stream.of(Rank.values()).forEach();
    }

    public void onLeave(Player player) {
        scoreboard.getTeams().forEach(team -> team.removeEntry(player.getName()));
    }

    public void onJoin(Player player, Rank rank) {
        player.setScoreboard(scoreboard);
        scoreboard.getTeam(rank.boardName()).addEntry(player.getName());
    }

    public void registerTeam(Rank rank) {
        Team team = scoreboard.registerNewTeam(rank.boardName());
        team.setPrefix(rank.prefix() + (rank.name().equals("RECRUIT") ? "" : ' '));
        team.setOption(Team.Option.COLLISION_RULE, Team.OptionStatus.NEVER);
    }
}
