package me.camdenorrb.buddercore.listeners;

import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.weather.WeatherChangeEvent;

/**
 * Created by camdenorrb on 10/16/16.
 */
public class WorldListener implements Listener {

    @EventHandler (ignoreCancelled = true)
    public void onWeather(WeatherChangeEvent e){
       if (e.toWeatherState()) e.setCancelled(true);
    }

}
