package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.mysql.MySql;
import me.camdenorrb.buddercore.mysql.SqlValueType;
import me.camdenorrb.buddercore.rank.Rank;
import me.camdenorrb.buddercore.store.AccountStore;
import me.camdenorrb.buddercore.utils.ChatUtils;
import me.camdenorrb.buddercore.utils.PlayerUtils;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.CommandSender;

import java.util.List;

/**
 * Created by camdenorrb on 10/15/16.
 */
public class TagCmd extends Command {

    private final MySql mySql;
    private final AccountStore accountStore;

    public TagCmd(AccountStore accountStore, MySql mySql) {
        super(Rank.DEV, 2, "&c/SetTag <PlayerName> [Tag - up to 16 characters]", "settag");
        this.mySql = mySql;
        this.accountStore = accountStore;
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {

        OfflinePlayer player = PlayerUtils.getOfflinePlayer(args.get(0));
        if (player == null) return false;

        String tag = ChatUtils.format(args.get(1));
        if (tag.length() > 16) return false;

        if (player.isOnline()) {
            accountStore.account(player.getUniqueId()).setTag(tag);
            player.getPlayer().sendMessage(ChatColor.GREEN + "Your new tag is " + tag + ChatColor.GREEN + '!');

        } else mySql.set(player.getUniqueId(), SqlValueType.TAG, tag);

        sender.sendMessage(ChatColor.GREEN + "Updated " + player.getName() + "'s tag to " + tag + ChatColor.GREEN  + '!');

        return true;
    }
}
