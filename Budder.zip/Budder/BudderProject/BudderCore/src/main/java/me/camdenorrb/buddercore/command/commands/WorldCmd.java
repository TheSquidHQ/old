package me.camdenorrb.buddercore.command.commands;

import me.camdenorrb.buddercore.account.Account;
import me.camdenorrb.buddercore.command.Command;
import me.camdenorrb.buddercore.rank.Rank;
import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;

import java.util.List;

/**
 * Created by camdenorrb on 10/15/16.
 */
public class WorldCmd extends Command {

    public WorldCmd() {
        super(Rank.DEV, 1, "&c/world <WorldName>", "world");
    }

    @Override
    public boolean execute(CommandSender sender, Account account, Rank rank, String commandName, List<String> args) {
        if (sender instanceof ConsoleCommandSender) return false;

        World world = Bukkit.getWorld(args.get(0));
        if (world == null) return false;

        ((Player) sender).teleport(world.getSpawnLocation());

        return true;
    }
}
